
Tienda Virtual VHNM - Ventas La Rioja
------------------------------------

Contenido: sitio estático listo para publicar. Usa localStorage para persistencia (demo).

Archivos:
- index.html      : Página principal (incluye React + Tailwind via CDN)
- assets/ventas_la_rioja_neon.png : Banner/logo en estilo neón.

Cómo publicar:
1) Subí la carpeta 'tienda_vhnm_la_rioja_site' a cualquier hosting estático (Netlify, Vercel, GitHub Pages).
2) Asegurate de que index.html y la carpeta assets estén en la raíz.
3) Para producción, reemplaza la persistencia localStorage por un backend y almacenamiento real de imágenes.

